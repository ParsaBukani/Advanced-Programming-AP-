#include "plants.hpp"
#include "blocks.hpp"
#include "header.hpp"
#include "zombies.hpp"
#include "start.hpp"
#include "game.hpp"
#include <utility>
#include <string>
#include <iostream>
#include <vector>

int main()
{
    if(isGameStarted()){
        sf::RenderWindow window(sf::VideoMode(1100, 600), "Plants vs Zombies");
        Game game;
        int checkEnd = game.run(window);
        if(checkEnd == 1)
            gameIsFinishedWasted();
        if(checkEnd == 2)
            gameIsFinishedWon();
    }
    return 0; 
}