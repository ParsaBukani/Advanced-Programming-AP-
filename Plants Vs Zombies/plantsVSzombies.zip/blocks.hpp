#pragma once

#include "header.hpp"
class IceshooterBlock;
class PeashooterBlock;
class Sun;
class WalnutBlock;
class Sun {
    private:
        sf::Vector2f position;
        sf::Texture texture;
        sf::Sprite sprite;
        sf::Font font;
        sf::Text sunText;
        int sunCount = 300;

    public:
        Sun();

        void draw(sf::RenderWindow& window);
        void update();
        void incrementCredit() { sunCount += 50; }
        int getCredit(){ return sunCount; }
        void calculateCredit(int debt){ sunCount -= debt; }
};
class StandingBonus{
    private:
        sf::Vector2f position;
        sf::Texture texture;
        sf::Sprite sprite;

    public:
        StandingBonus(const sf::Vector2f& pos);
        void draw(sf::RenderWindow& window);
        sf::Sprite getSprite(){ return sprite; }
};
class Bonus{
    private:
        sf::Vector2f position;
        sf::Texture texture;
        sf::Sprite sprite;
        int speed;

    public:
        Bonus(const sf::Vector2f& pos);

        void update(float dt);
        void draw(sf::RenderWindow& window);
        float getYCordinate(){ return position.y; }
        sf::Sprite getSprite(){ return sprite; }
};
class PeashooterBlock{
    private:
        sf::Vector2f position;
        sf::Texture activeTexture;
        sf::Texture inActiveTexture;
        sf::Sprite sprite;
        sf::Font font;
        sf::Text PeashooterBlockText;

        int price;
        int coolDown;
        int inActivationTime = coolDown;
        int inActivationCount = coolDown + 1;
        bool statue = true;
        bool isSpawning = false;
        bool startCounting = false;

        sf::Vector2f peashooterPos;
        sf::Texture peashooterTex;
        sf::Sprite peashooterSpr;

    public:
        PeashooterBlock();

        void draw(sf::RenderWindow& window);
        void update(float dt, sf::Clock gameClock, sf::RenderWindow& window, int credit);
        void spawn(sf::RenderWindow& window);
        void reset(sf::Clock gameClock, bool isInGridCell);

        sf::Sprite getSprite(){ return sprite; }
        int getPrice(){ return price; }
        bool getStatue(){ return statue; }
        bool getSpawningStatue() { return isSpawning; }
};
class WalnutBlock{
    private:
        sf::Vector2f position;
        sf::Texture activeTexture;
        sf::Texture inActiveTexture;
        sf::Sprite sprite;
        sf::Font font;
        sf::Text WalnutBlockText;

        int price;
        int coolDown;
        int inActivationTime = coolDown;
        int inActivationCount = coolDown + 1;
        bool statue = true;
        bool isSpawning = false;
        bool startCounting = false;

        sf::Vector2f walnutPos;
        sf::Texture walnutTex;
        sf::Sprite walnutSpr;

    public:
        WalnutBlock();

        void draw(sf::RenderWindow& window);
        void update(float dt, sf::Clock gameClock, sf::RenderWindow& window, int credit);
        void spawn(sf::RenderWindow& window);
        void reset(sf::Clock gameClock, bool isInGridCell);

        sf::Sprite getSprite(){ return sprite; }
        int getPrice(){ return price; }
        bool getStatue(){ return statue; }
        bool getSpawningStatue() { return isSpawning; }
};
class IceshooterBlock{
    private:
        sf::Vector2f position;
        sf::Texture activeTexture;
        sf::Texture inActiveTexture;
        sf::Sprite sprite;
        sf::Font font;
        sf::Text IceshooterBlockText;

        int price;
        int coolDown;
        int inActivationTime = coolDown;
        int inActivationCount = coolDown + 1;
        bool statue = true;
        bool isSpawning = false;
        bool startCounting = false;

        sf::Vector2f iceshooterPos;
        sf::Texture iceshooterTex;
        sf::Sprite iceshooterSpr;

    public:
        IceshooterBlock();

        void draw(sf::RenderWindow& window);
        void update(float dt, sf::Clock gameClock, sf::RenderWindow& window, int credit);
        void spawn(sf::RenderWindow& window);
        void reset(sf::Clock gameClock, bool isInGridCell);

        sf::Sprite getSprite(){ return sprite; }
        int getPrice(){ return price; }
        bool getStatue(){ return statue; }
        bool getSpawningStatue() { return isSpawning; }
};
class SunflowerBlock{
    private:
        sf::Vector2f position;
        sf::Texture activeTexture;
        sf::Texture inActiveTexture;
        sf::Sprite sprite;
        sf::Font font;
        sf::Text SunflowerBlockText;

        int price;
        int coolDown;
        int inActivationTime = coolDown;
        int inActivationCount = coolDown + 1;
        bool statue = true;
        bool isSpawning = false;
        bool startCounting = false;

        sf::Vector2f sunflowerPos;
        sf::Texture sunflowerTex;
        sf::Sprite sunflowerSpr;

    public:
        SunflowerBlock();

        void draw(sf::RenderWindow& window);
        void update(float dt, sf::Clock gameClock, sf::RenderWindow& window, int credit);
        void spawn(sf::RenderWindow& window);
        void reset(sf::Clock gameClock, bool isInGridCell);

        sf::Sprite getSprite(){ return sprite; }
        int getPrice(){ return price; }
        bool getStatue(){ return statue; }
        bool getSpawningStatue() { return isSpawning; }
};