#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <utility>
#include <vector>
#include <string>

using namespace std;

const string CSV_FILE_PATH = "info.csv";
const string MEDIUM_Zombie_TEXTURE_FILE_PATH = "pics/Zombie_healthy.png";     
const string MEGA_Zombie_TEXTURE_FILE_PATH = "pics/megazombie.png"; 

const string SUNFLOWER_ACTIVE_TEXTUR_FILE_PATH = "pics/icon_sunflower.png";
const string SUNFLOWER_INACTIVE_TEXTUR_FILE_PATH = "pics/icon_sunflower_dim.png";

const string PEASHOOTER_ACTIVE_TEXTUR_FILE_PATH = "pics/peashooter-icon.png";
const string PEASHOOTER_INACTIVE_TEXTUR_FILE_PATH = "pics/icon_peashooter_100_dim.png";

const string ICESHOOTER_ACTIVE_TEXTUR_FILE_PATH = "pics/iceshooter-icon.png";
const string ICESHOOTER_INACTIVE_TEXTUR_FILE_PATH = "pics/snowpea-dim.jpg";

const string WALNUT_ACTIVE_TEXTUR_FILE_PATH = "pics/walnut-icon.png";
const string WALNUT_INACTIVE_TEXTUR_FILE_PATH = "pics/icon_walnut_dim.png";

const string SUN_TEXTUR_FILE_PATH = "pics/sun.png";
const string TEXT_FILE_PATH = "textModel.otf";

const string BACK_GROUND_IMAGE_PATH = "pics/Frontyard.png";
const string MUSIC_AUDIO_FILE_PATH = "ingame.ogg";

const string ICESHOOTER_ARROW_TEXTURE_FILE_PATH = "pics/pea.png";
const string PEASHOOTER_ARROW_TEXTURE_FILE_PATH = "pics/pea.png";
const string SUNFLOWER_TEXTURE_FILE_PATH = "pics/Sunflower.png";
const string WALNUT_BODEY_TEXTURE_FILE_PATH = "pics/Wallnut_body.png";
const string WALNUT_CRACKED1_TEXTURE_FILE_PATH = "pics/Wallnut_cracked1.png";
const string WALNUT_CRACKED2_TEXTURE_FILE_PATH = "pics/Wallnut_cracked2.png";
const string PEASHOOTER_TEXTURE_FILE_PATH = "pics/Peashooter.png";
const string ICESHOOTER_TEXTURE_FILE_PATH = "pics/iceshooter-icon.png";
const string START_PAGE = "pics/startPage.png";

const float GRID_TOP_LEFT_X = 245;  
const float GRID_TOP_LEFT_Y = 75;      
const float CELL_WIDTH = 83;        
const float CELL_HEIGHT = 97;       
const int GRID_COLUMNS = 9;     
const int GRID_ROWS = 5;

const int SUN_POSITION_X_AXIS = 45;
const int SUN_POSITION_Y_AXIS = 35;
const int BLOCK_TOP_CENTRE_X = 45;
const int BLOCK_TOP_CENTRE_Y = 35;
const int BLOCK_HEIGHT = 80;

// csv indexes:
const int DAMAGE = 1; 
const int HEALTH = 2;
const int HITRATE = 3;
const int SPEED = 4;
const int P_HITRATE = 4;
const int P_SPEED = 5;
const int PRICE = 6;
const int TOTALL_TIME_TO_WIN = 1;
const int ZOMBIE_SPAWN_RATE = 2;
const int NUM_OF_ZOMBIES_TO_SPAWN = 3;
const int NUM_OF_ZOMBIES_TO_ADD = 4;
const int SUN_SPAWN_INTERVAL = 2;
const int SUN_SPEED = 1;
const int COOLDOWN = 3;
const int ICE_FREEZE_TIME = 5;
const int ONE_SECOND = 1;