#include "plants.hpp"
#include "zombies.hpp"

class MegaZombie;



bool hasCollision(const sf::Sprite& sprite1, const sf::Sprite& sprite2) {
    sf::FloatRect boundingBox1 = sprite1.getGlobalBounds();
    sf::FloatRect boundingBox2 = sprite2.getGlobalBounds();
    float center1_x = boundingBox1.width /2 + boundingBox1.left;
    float center2_x = boundingBox2.width /2 + boundingBox2.left;
    float center1_y = boundingBox1.top + boundingBox1.height /2 ;
    float center2_y = boundingBox2.top + boundingBox2.height /2;
    float distance_x = center1_x - center2_x;
    return ((distance_x < (boundingBox1.width + boundingBox2.width) / 2 - 30))&& (center1_y == center2_y);
}



Sunflower::Sunflower(const sf::Vector2f& pos) : position(pos) {
    health = readFromFile("sunflower", HEALTH);
    spawnRate = readFromFile("sunflower", HITRATE);

    texture.loadFromFile(SUNFLOWER_TEXTURE_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.05f,0.05f);
}

void Sunflower::draw(sf::RenderWindow& window){  
         window.draw(sprite);
}

void Sunflower::manageHealth(int damage) {
    health -= damage;   
}

bool Sunflower::isDead(){
    if (health <= 0)
        return true;
    return false;
}






PeaArrow::PeaArrow(const sf::Vector2f& pos) : position(pos) {
    speed = readFromFile("peashooter", P_SPEED);
    damage = readFromFile("peashooter", DAMAGE);

    texture.loadFromFile(PEASHOOTER_ARROW_TEXTURE_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.17f,0.17f);
}

void PeaArrow::draw(sf::RenderWindow& window){  
         window.draw(sprite);
}
void PeaArrow::update(float dt, vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies){
    position.x += speed*dt;
    sprite.setPosition(position);

    for(auto& medZombie : mediumZombies){
        if(hasCollision(medZombie->getSprite(), sprite)){
            medZombie->manageHealth(damage);
            hadCollision = true;
        }
    }
    for(auto& megZombie : megaZombies){
        if(hasCollision(megZombie->getSprite(), sprite)){
            megZombie->manageHealth(damage);
            hadCollision = true;
        }
    }
}





Peashooter::Peashooter(const sf::Vector2f& pos) : position(pos) {
    health = readFromFile("peashooter", HEALTH);

    texture.loadFromFile(PEASHOOTER_TEXTURE_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.05f,0.05f);
}

void Peashooter::draw(sf::RenderWindow& window){  
    window.draw(sprite);
    for(auto& arrow : peaArrows){
        arrow->draw(window);
    }
}

void Peashooter::manageHealth(int damage){
    health -= damage;
    if (health <= 0)
        Dead = true; 
}

void Peashooter::spawnArrow(){
    peaArrows.push_back(new PeaArrow(position));
}

void Peashooter::update(float dt, sf::Clock gameClock, vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    if(gameTime > hitRate){
        if(isZombieComing(mediumZombies, megaZombies)){
            if(firstSpawn){
                hitRate = gameTime;
                firstSpawn = false;
            } else {
                spawnArrow();
                hitRate += readFromFile("peashooter", P_HITRATE);
            }
        }
    }

    for(auto& arrow : peaArrows){
        arrow->update(dt, mediumZombies, megaZombies);
    }

    for(auto& arrow : peaArrows){
        if(arrow->isHit())
            removeArrow(arrow);
    }
}

void Peashooter::removeArrow(PeaArrow* arrow){
    auto it = find(peaArrows.begin(), peaArrows.end(), arrow);

    if (it != peaArrows.end()) {
        peaArrows.erase(it);
        delete arrow;
    }
}

bool Peashooter::isZombieComing(vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies){
    for(auto& medZombie : mediumZombies){
        if(medZombie->getPosition().y == position.y)
            return true;
    }
    for(auto& megZombie : megaZombies){
        if(megZombie->getPosition().y == position.y)
            return true;
    }
    return false;
}






IceArrow::IceArrow(const sf::Vector2f& pos) : position(pos)  {
    speed = readFromFile("iceshooter", P_SPEED);
    damage = readFromFile("iceshooter", DAMAGE);

    texture.loadFromFile(ICESHOOTER_ARROW_TEXTURE_FILE_PATH);
    sprite.setTexture(texture);
    sprite.setColor(sf::Color(5.f,70.f,235.0f));
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.17f,0.17f);
}

void IceArrow::draw(sf::RenderWindow& window){  
    window.draw(sprite);
}

void IceArrow::update(float dt, float gameTime, vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies){
    position.x += speed*dt;
    sprite.setPosition(position);

    for(auto& medZombie : mediumZombies){
        if(hasCollision(medZombie->getSprite(), sprite)){
            medZombie->manageHealth(damage);
            medZombie->handleIceHit(gameTime);
            hadCollision = true;
        }
    }
    for(auto& megZombie : megaZombies){
        if(hasCollision(megZombie->getSprite(), sprite)){
            megZombie->manageHealth(damage);
            megZombie->handleIceHit(gameTime);
            hadCollision = true;
        }
    }
}






IceShooter::IceShooter(const sf::Vector2f& pos) : position(pos){
    health = readFromFile("iceshooter", HEALTH);

    texture.loadFromFile(ICESHOOTER_TEXTURE_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(-10 + bounds.width / 2, -24 + bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.30f,0.51f);
}


void IceShooter::draw(sf::RenderWindow& window){  
    window.draw(sprite);
    for(auto& arrow : iceArrows){
        arrow->draw(window);
    }
}

void IceShooter::manageHealth(int damage){
    health -= damage;
    if (health <= 0)
        Dead = true; 
}

void IceShooter::spawnArrow(){
    iceArrows.push_back(new IceArrow(position));
}

void IceShooter::update(float dt, sf::Clock gameClock, vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    if(gameTime > hitRate){
        if(isZombiesComing(mediumZombies, megaZombies)){
            if(firstSpawn){
                hitRate = gameTime;
                firstSpawn = false;
            } else {
                spawnArrow();
                hitRate += readFromFile("iceshooter", P_HITRATE);
            }
        }
    }

    for(auto& arrow : iceArrows){
        arrow->update(dt, gameTime, mediumZombies, megaZombies);
    }

    for(auto& arrow : iceArrows){
        if(arrow->isHit())
            removeArrow(arrow);
    }
}

void IceShooter::removeArrow(IceArrow* arrow){
    auto it = find(iceArrows.begin(), iceArrows.end(), arrow);

    if (it != iceArrows.end()) {
        iceArrows.erase(it);
        delete arrow;
    }
}

bool IceShooter::isZombiesComing(vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies){
    for(auto& medZombie : mediumZombies){
        if(medZombie->getPosition().y == position.y)
            return true;
    }
    for(auto& megZombie : megaZombies){
        if(megZombie->getPosition().y == position.y)
            return true;
    }
    return false;
}






Walnut::Walnut(const sf::Vector2f& pos) : position(pos) {
    health = readFromFile("walnut", HEALTH);

    bodyTexture.loadFromFile(WALNUT_BODEY_TEXTURE_FILE_PATH);
    crackedTexture1.loadFromFile(WALNUT_CRACKED1_TEXTURE_FILE_PATH);
    crackedTexture2.loadFromFile(WALNUT_CRACKED2_TEXTURE_FILE_PATH);
    sprite.setTexture(bodyTexture);
    sf::FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.7f,0.7f);
}

void Walnut::draw(sf::RenderWindow& window){  
    if(health >= (2*readFromFile("walnut", HEALTH))/3){
        sprite.setTexture(bodyTexture);
        window.draw(sprite);
    } else if(health >= readFromFile("walnut", HEALTH)/3){
        sprite.setTexture(crackedTexture1);
        window.draw(sprite);
    } else {
        sprite.setTexture(crackedTexture2);
        window.draw(sprite);
    }
}

void Walnut::manageHealth(int damage){
    health -= damage; 
}

bool Walnut::isDead(){
    if (health <= 0)
        return true;
    return false;
}
