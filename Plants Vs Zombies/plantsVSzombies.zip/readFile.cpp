#include "readFile.hpp"
#include <string>
#include <fstream>
using namespace std;



string tokenize(char index, int placing, string line)
{
    line += index;
    int counter = 1;
    string substring = "";
    for(auto x : line){
        if(x == index)
        {
            if(counter == placing)
                return substring;
            else{
                counter++;
                substring = "";
            }
        }
        else
            substring = substring + x;
    }
    return "";
}

int readFromFile(string object, int property){
    ifstream file(CSV_FILE_PATH);

    string line;
    while (getline(file, line))
    {
        string type = tokenize(',', 1, line);
        if(type == object){
            return stoi(tokenize(',', 1+property, line));
        }
    }
    return 0;
}

