#pragma once
#include "header.hpp"
int readFromFile(string object, int property);
string tokenize(char index, int placing, string line);