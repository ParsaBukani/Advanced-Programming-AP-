#include <utility>
#include <string>
#include <iostream>
#include <vector>
#include "plants.hpp"
#include "blocks.hpp"
#include "header.hpp"
#include "zombies.hpp"
#include "start.hpp"
#include "game.hpp"




Game::Game() {
    totallTimeToWin = readFromFile("ATTAKS", TOTALL_TIME_TO_WIN);
    zombieSpawnRate = readFromFile("ATTAKS", ZOMBIE_SPAWN_RATE);
    numOfZombiesToSpawn = readFromFile("ATTAKS", NUM_OF_ZOMBIES_TO_SPAWN);
    numOfZombiesTOAdd = readFromFile("ATTAKS", NUM_OF_ZOMBIES_TO_ADD);
    SunSpawnRate = readFromFile("ATTAKS", SUN_SPAWN_INTERVAL);

    music.openFromFile(MUSIC_AUDIO_FILE_PATH);

    backgroundTexture.loadFromFile(BACK_GROUND_IMAGE_PATH);
    backgroundSprite.setTexture(backgroundTexture);

    gridPositions.resize(GRID_ROWS, vector<pair<sf::Vector2f,bool>>(GRID_COLUMNS));

    for (int i = 0; i < GRID_ROWS; ++i) {
        for (int j = 0; j < GRID_COLUMNS; ++j) {
            gridPositions[i][j].first = sf::Vector2f((GRID_TOP_LEFT_X + CELL_WIDTH/2) + j * CELL_WIDTH, (GRID_TOP_LEFT_Y + CELL_HEIGHT/2) + i * CELL_HEIGHT);
            gridPositions[i][j].second = false;
        }
    }
}
void Game::isLost(vector<MediumZombie*> mediumZombies,vector<MegaZombie*> megaZombies){
    for(auto& med : mediumZombies){
        if(med->getPosition().x < GRID_TOP_LEFT_X)
            isLose = true;
    }
    for(auto& mega : megaZombies){
        if(mega->getPosition().x < GRID_TOP_LEFT_X)
            isLose = true;
    }   
}

int Game::run(sf::RenderWindow& window){
    sf::Clock clock;
    music.play();
    while (window.isOpen() && !isLose && !isWin) {
        sf::Time deltaTime = clock.restart();
        float dtSeconds = deltaTime.asSeconds();

        sf::Event event;
        sf::Clock eventClock;
        while (window.pollEvent(event)){
            if (event.type == sf::Event::Closed)
                window.close();

            handleInput(event, window);
        }
        update(dtSeconds, window);
        window.clear();
        render(window);
        window.display();
    }
    music.stop();      
    window.close();
    if(isLose)
        return 1;
    else if (isWin)
        return 2;  
    else 
        return 3;     
}


void Game::handleInput(sf::Event& event, sf::RenderWindow& window) {
    if (event.type == sf::Event::MouseButtonReleased) {
        sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
        if(checkBonuses(mousePosition))
            return;
        if(checkStandingBonuses(mousePosition))
            return;
        checkPeashooterBlock(mousePosition, window);
        checkWalnutBlock(mousePosition, window);
        checkIceshooterBlock(mousePosition, window);
        checkSunflowerBlock(mousePosition, window);
        sf::Vector2f gridPosition = getGridCenterPosition(mousePosition);
    }
}


void Game::update(float dtSeconds, sf::RenderWindow& window) {
    for(int i = 0; i < mediumZombies.size(); i++){
        if(mediumZombies[i]->isDead()){
            removeMedZombie(mediumZombies[i]);
            continue;
        }
        mediumZombies[i]->update(dtSeconds, gameClock.getElapsedTime().asSeconds());
    }
    for(int i = 0; i < megaZombies.size(); i++){
        if(megaZombies[i]->isDead()){
            removeMegaZombie(megaZombies[i]);
            continue;
        }
        megaZombies[i]->update(dtSeconds,gameClock.getElapsedTime().asSeconds());
    }
    for(int i = 0; i < bonuses.size(); i++){
        bonuses[i]->update(dtSeconds);
    }
    for(int i = 0; i < peashooters.size(); i++){
        if(peashooters[i]->isDead()){
            removePeashooter(peashooters[i], peashooters[i]->getPosition());
            continue;
        }
        peashooters[i]->update(dtSeconds, gameClock, mediumZombies, megaZombies);
    }
    for(int i = 0; i < iceShooters.size(); i++){
        if(iceShooters[i]->isDead()){
            removeIceshooter(iceShooters[i], iceShooters[i]->getPosition());
            continue;
        }
        iceShooters[i]->update(dtSeconds, gameClock, mediumZombies, megaZombies);
    }
    for(int i = 0; i < sunflowers.size(); i++){
        if(sunflowers[i]->isDead())
            removeSunflower(sunflowers[i], sunflowers[i]->getPosition());
    }
    for(int i = 0; i < walnuts.size(); i++){
        if(walnuts[i]->isDead())
            removeWulnut(walnuts[i], walnuts[i]->getPosition());
    }

    checkZombiesEatingPlants(dtSeconds);
    spawnZombies();
    spawnSun();
    spawnSun2(sunflowers);
    sun.update();
    peashooterBlock.update(dtSeconds, gameClock, window, sun.getCredit());
    walnutBlock.update(dtSeconds, gameClock, window,sun.getCredit());
    iceshooterBlock.update(dtSeconds, gameClock, window,sun.getCredit());
    sunflowerBlock.update(dtSeconds, gameClock, window,sun.getCredit());
    isLost(mediumZombies,megaZombies);
    isWon();
}


void Game::render(sf::RenderWindow& window)
{
    window.draw(backgroundSprite);
    sun.draw(window);
    peashooterBlock.draw(window);
    walnutBlock.draw(window);
    iceshooterBlock.draw(window);
    sunflowerBlock.draw(window);
    for(int i=0; i < sunflowers.size(); i++){
        sunflowers[i]->draw(window);
    }
    for(int i=0; i < walnuts.size(); i++){
        walnuts[i]->draw(window);
    }
    for(int i=0; i < peashooters.size(); i++){
        peashooters[i]->draw(window);
    }
    for(int i=0; i < iceShooters.size(); i++){
        iceShooters[i]->draw(window);
    }        
    for(int i=0; i < mediumZombies.size(); i++){
        mediumZombies[i]->draw(window);
    }
    for(int i=0; i < megaZombies.size(); i++){
        megaZombies[i]->draw(window);
    }
    for(int i=0; i < bonuses.size(); i++){
        bonuses[i]->draw(window);
    }
    for(int i=0; i < standingbonuses.size(); i++){
        standingbonuses[i]->draw(window);
    }
}


void Game::addSunflower(sf::Vector2f position) {
    float gameTime = gameClock.getElapsedTime().asSeconds();

    fillGridCell(position);
    Sunflower* newSunflower = new Sunflower(position);
    newSunflower->setSpawnRate(gameTime);
    sunflowers.push_back(newSunflower);
}
void Game::addPeashooter(sf::Vector2f position) {
    fillGridCell(position);
    Peashooter* newPeshooter = new Peashooter(position);
    peashooters.push_back(newPeshooter);
}
void Game::addWalnut(sf::Vector2f position) {
    fillGridCell(position);
    Walnut* newWalnut = new Walnut(position);
    walnuts.push_back(newWalnut);
}
void Game::addIceshooter(sf::Vector2f position) {
    fillGridCell(position);
    IceShooter* newIceshooter = new IceShooter(position);
    iceShooters.push_back(newIceshooter);
}
void Game::addMediumZombie(sf::Vector2f position) {
    fillGridCell(position);
    MediumZombie* newMediumZombie = new MediumZombie(position);
    mediumZombies.push_back(newMediumZombie);
}
void Game::addMegaZombie(sf::Vector2f position) {
    fillGridCell(position);
    MegaZombie* newMegaZombie = new MegaZombie(position);
    megaZombies.push_back(newMegaZombie);
}


sf::Vector2f Game::getGridCenterPosition(const sf::Vector2i& mousePosition) {
    for (int i = 0; i < GRID_ROWS; ++i) {
        for (int j = 0; j < GRID_COLUMNS; ++j) {
            sf::Vector2f cellTopLeft = gridPositions[i][j].first - sf::Vector2f(CELL_WIDTH/2, CELL_HEIGHT/2);
            sf::Vector2f cellBottomRight = cellTopLeft + sf::Vector2f(CELL_WIDTH, CELL_HEIGHT);
            if (mousePosition.x >= cellTopLeft.x && mousePosition.x <= cellBottomRight.x &&
                mousePosition.y >= cellTopLeft.y && mousePosition.y <= cellBottomRight.y) {
                if(gridPositions[i][j].second == false)    
                    return gridPositions[i][j].first;
                else 
                    break;
            }
        }
    }
    return sf::Vector2f(-1, -1);
}

void Game::fillGridCell(sf::Vector2f position){
   for (int i = 0; i < GRID_ROWS; ++i) {
        for (int j = 0; j < GRID_COLUMNS; ++j) {
            if(gridPositions[i][j].first == position){
                gridPositions[i][j].second = true;
                return;
            }
        }
    }
}


void Game::resetGridCell(sf::Vector2f position){
    for (int i = 0; i < GRID_ROWS; ++i) {
        for (int j = 0; j < GRID_COLUMNS; ++j) {
            if(gridPositions[i][j].first == position){
                gridPositions[i][j].second = false;
                return;
            }
        }
    }
}


void Game::spawnZombies(){
    float gameTime = gameClock.getElapsedTime().asSeconds();
    if (gameTime >= zombieSpawnRate) {
        for (int i = 0; i < numOfZombiesToSpawn; ++i) {
            int startingLine = rand()%20;
            if(startingLine == 0)
             startingLine++;

            sf::Vector2f zombiePosition = gridPositions[rand()%GRID_ROWS][GRID_COLUMNS-1].first + sf::Vector2f(CELL_WIDTH/startingLine, 0);
            int zombieType = rand()%2;
            if(zombieType == 0)
                addMediumZombie(zombiePosition);
            else{
                if(gameTime >= 40)
                    addMegaZombie(zombiePosition);
                else
                    addMediumZombie(zombiePosition);
            }    
        }
        zombieSpawnRate += zombieSpawnRate;
        numOfZombiesToSpawn += numOfZombiesTOAdd;
    }
}

void Game::removeMedZombie(MediumZombie* mediumZombie){
    auto it = find(mediumZombies.begin(), mediumZombies.end(), mediumZombie);

    if (it != mediumZombies.end()) {
        mediumZombies.erase(it);
        delete mediumZombie;
    }
}

void Game::removeMegaZombie(MegaZombie* megaZombie){
    auto it = find(megaZombies.begin(), megaZombies.end(), megaZombie);

    if (it != megaZombies.end()) {
        megaZombies.erase(it);
        delete megaZombie;
    }
}

void Game::removePeashooter(Peashooter* peashooter, sf::Vector2f position){
    resetGridCell(position);
    auto it = find(peashooters.begin(), peashooters.end(), peashooter);

    if (it != peashooters.end()) {
        peashooters.erase(it);
        delete peashooter;
    }
}

void Game::removeIceshooter(IceShooter* iceshooter, sf::Vector2f position){
    resetGridCell(position);
    auto it = find(iceShooters.begin(), iceShooters.end(), iceshooter);

    if (it != iceShooters.end()) {
        iceShooters.erase(it);
        delete iceshooter;
    }
}

void Game::removeSunflower(Sunflower* sunflower, sf::Vector2f position){
    resetGridCell(position);
    auto it = find(sunflowers.begin(), sunflowers.end(), sunflower);

    if (it != sunflowers.end()) {
        sunflowers.erase(it);
        delete sunflower;
    }
}
        
void Game::removeWulnut(Walnut* Walnut, sf::Vector2f position){
    resetGridCell(position);
    auto it = find(walnuts.begin(), walnuts.end(), Walnut);

    if (it != walnuts.end()) {
        walnuts.erase(it);
        delete Walnut;
    }
}

void Game::spawnSun(){
    float gameTime = gameClock.getElapsedTime().asSeconds();
    if(gameTime >= SunSpawnRate){
        int randomX = std::rand() % 1101;
        Bonus* newSun = new Bonus(sf::Vector2f(randomX, 0));
        
        bonuses.push_back(newSun);
        

        SunSpawnRate += SunSpawnRate;
    }
}

void Game::spawnSun2(vector<Sunflower*> sunflowers){
    float gameTime = gameClock.getElapsedTime().asSeconds();
    
    for(int i = 0 ; i < sunflowers.size() ; i++){
        if(gameTime >= sunflowers[i]->getSpawnRate()){

            StandingBonus* newSun = new StandingBonus(sunflowers[i]->getPosition());

            standingbonuses.push_back(newSun);
            sunflowers[i]->updateSpawnRate();
        }
    }
}

bool Game::checkBonuses(const sf::Vector2i& mousePosition){
    bool isClickedBonus = false;
    for (Bonus* bonus : bonuses) {
        sf::FloatRect sunBounds = bonus->getSprite().getGlobalBounds();
        if (sunBounds.contains(sf::Vector2f(mousePosition))) {
            sun.incrementCredit();
            removeBonus(bonus);
            isClickedBonus = true;
            break;
        }
    }
    for(Bonus* bonus : bonuses){
        if(bonus->getYCordinate() >= 600) {// 600 is the height of the window
            removeBonus(bonus);
        }
    }
    return isClickedBonus;
}

bool Game::checkStandingBonuses(const sf::Vector2i& mousePosition){
    bool isClickedBonus = false;
    for (StandingBonus* standingbonuse : standingbonuses) {
        sf::FloatRect sunBounds = standingbonuse->getSprite().getGlobalBounds();
        if (sunBounds.contains(sf::Vector2f(mousePosition))) {
            sun.incrementCredit();
            removeStandingBonus(standingbonuse);
            isClickedBonus = true;
            break;
        }
    }

    return isClickedBonus;
}


void Game::removeBonus(Bonus* bonus) {
    auto it = find(bonuses.begin(), bonuses.end(), bonus);

    if (it != bonuses.end()) {
        bonuses.erase(it);
        delete bonus;
    }
}
void Game::removeStandingBonus(StandingBonus* standingbonus) {
    auto it = find(standingbonuses.begin(), standingbonuses.end(), standingbonus);

    if (it != standingbonuses.end()) {
        standingbonuses.erase(it);
        delete standingbonus;
    }
}

void Game::checkPeashooterBlock(const sf::Vector2i& mousePosition, sf::RenderWindow& window){
    if(peashooterBlock.getSpawningStatue() == true){
        bool isInGridCell;
        sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
        sf::Vector2f gridPosition = getGridCenterPosition(mousePosition);
        if (gridPosition.x != -1 && gridPosition.y != -1){
            addPeashooter(gridPosition);

            int debt = peashooterBlock.getPrice();
            sun.calculateCredit(debt);

            isInGridCell = true;
        } else 
            isInGridCell = false;
    
        peashooterBlock.reset(gameClock, isInGridCell);
        return;
    }

    sf::FloatRect blockBounds = peashooterBlock.getSprite().getGlobalBounds();
    if ((peashooterBlock.getSpawningStatue() == false) && blockBounds.contains(sf::Vector2f(mousePosition)) && peashooterBlock.getStatue()) { // don't need to check for peashooterBlock.getSpawningStatue() == false
        if (sun.getCredit() >= peashooterBlock.getPrice()){
            peashooterBlock.spawn(window);
        }
    }
}

void Game::checkWalnutBlock(const sf::Vector2i& mousePosition, sf::RenderWindow& window){
    if(walnutBlock.getSpawningStatue() == true){
        bool isInGridCell;
        sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
        sf::Vector2f gridPosition = getGridCenterPosition(mousePosition);
        if (gridPosition.x != -1 && gridPosition.y != -1){
            addWalnut(gridPosition);

            int debt = walnutBlock.getPrice();
            sun.calculateCredit(debt);

            isInGridCell = true;
        } else 
            isInGridCell = false;
    
        walnutBlock.reset(gameClock, isInGridCell);
        return;
    }

    sf::FloatRect blockBounds = walnutBlock.getSprite().getGlobalBounds();
    if ((walnutBlock.getSpawningStatue() == false) && blockBounds.contains(sf::Vector2f(mousePosition)) && walnutBlock.getStatue()) { // don't need to check for walnutBlock.getSpawningStatue() == false
        if (sun.getCredit() >= walnutBlock.getPrice()){
            walnutBlock.spawn(window);
        }
    }
}

void Game::checkIceshooterBlock(const sf::Vector2i& mousePosition, sf::RenderWindow& window){
    if(iceshooterBlock.getSpawningStatue() == true){
        bool isInGridCell;
        sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
        sf::Vector2f gridPosition = getGridCenterPosition(mousePosition);
        if (gridPosition.x != -1 && gridPosition.y != -1){
            addIceshooter(gridPosition);

            int debt = iceshooterBlock.getPrice();
            sun.calculateCredit(debt);

            isInGridCell = true;
        } else 
            isInGridCell = false;
    
        iceshooterBlock.reset(gameClock, isInGridCell);
        return;
    }

    sf::FloatRect blockBounds = iceshooterBlock.getSprite().getGlobalBounds();
    if ((iceshooterBlock.getSpawningStatue() == false) && blockBounds.contains(sf::Vector2f(mousePosition)) && iceshooterBlock.getStatue()) { // don't need to check for iceshooterBlock.getSpawningStatue() == false
        if (sun.getCredit() >= iceshooterBlock.getPrice()){
            iceshooterBlock.spawn(window);
        }
    }
}

void Game::checkSunflowerBlock(const sf::Vector2i& mousePosition, sf::RenderWindow& window){
    if(sunflowerBlock.getSpawningStatue() == true){
        bool isInGridCell;
        sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
        sf::Vector2f gridPosition = getGridCenterPosition(mousePosition);
        if (gridPosition.x != -1 && gridPosition.y != -1){
            addSunflower(gridPosition);

            int debt = sunflowerBlock.getPrice();
            sun.calculateCredit(debt);

            isInGridCell = true;
        } else 
            isInGridCell = false;
    
        sunflowerBlock.reset(gameClock, isInGridCell);
        return;
    }

    sf::FloatRect blockBounds = sunflowerBlock.getSprite().getGlobalBounds();
    if ((sunflowerBlock.getSpawningStatue() == false) && blockBounds.contains(sf::Vector2f(mousePosition)) && sunflowerBlock.getStatue()) { // don't need to check for sunflowerBlock.getSpawningStatue() == false
        if (sun.getCredit() >= sunflowerBlock.getPrice()){
            sunflowerBlock.spawn(window);
        }
    }
}

void Game::checkZombiesEatingPlants(float dt){
    checkZombiesEatingPeashooter(dt);
    checkZombiesEatingIceshooter(dt);
    checkZombiesEatingSunflower(dt);
    checkZombiesEatingWalnut(dt);
}


void Game::checkZombiesEatingPeashooter(float dt){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    for(auto& peashooter : peashooters){
        sf::Vector2f peashooterPos = peashooter->getPosition();
        
        for(auto& medZombie : mediumZombies){
            sf::Vector2f medZombiePos = medZombie->getPosition();

            if((medZombiePos.y == peashooterPos.y) && (medZombiePos.x > peashooterPos.x && medZombiePos.x < (peashooterPos.x + 40))){
                medZombie->setPosition({medZombiePos.x += dt*medZombie->getSpeed(), medZombiePos.y});
                if(gameTime >= medZombie->getHitRate()){
                   if(medZombie->isFirstRate()){
                        medZombie->resetRateStatue();
                        medZombie->setFirstHitRate(gameTime);
                    } else {
                        peashooter->manageHealth(medZombie->getDamage());
                        if(peashooter->isDead())
                            medZombie->setFirstRate();
                    }
                    medZombie->resetHitRate();
                }
            }
        }

        for(auto& megaZombie : megaZombies){
            sf::Vector2f megaZombiePos = megaZombie->getPosition();

            if((megaZombiePos.y == peashooterPos.y) && (megaZombiePos.x > peashooterPos.x && megaZombiePos.x < (peashooterPos.x + 40))){
                megaZombie->setPosition({megaZombiePos.x += dt*megaZombie->getSpeed(), megaZombiePos.y});
                if(gameTime >= megaZombie->getHitRate()){
                   if(megaZombie->isFirstRate()){
                        megaZombie->resetRateStatue();
                        megaZombie->setFirstHitRate(gameTime);
                    } else {
                        peashooter->manageHealth(megaZombie->getDamage());
                        if(peashooter->isDead())
                            megaZombie->setFirstRate();
                    }
                    megaZombie->resetHitRate();
                }
            }
        }
    }
}

void Game::checkZombiesEatingIceshooter(float dt){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    for(auto& iceshooter : iceShooters){
        sf::Vector2f iceshooterPos = iceshooter->getPosition();
        
        for(auto& medZombie : mediumZombies){
            sf::Vector2f medZombiePos = medZombie->getPosition();

            if((medZombiePos.y == iceshooterPos.y) && (medZombiePos.x > iceshooterPos.x && medZombiePos.x < (iceshooterPos.x + 40))){
                medZombie->setPosition({medZombiePos.x += dt*medZombie->getSpeed(), medZombiePos.y});
                if(gameTime >= medZombie->getHitRate()){
                   if(medZombie->isFirstRate()){
                        medZombie->resetRateStatue();
                        medZombie->setFirstHitRate(gameTime);
                    } else {
                        iceshooter->manageHealth(medZombie->getDamage());
                        if(iceshooter->isDead())
                            medZombie->setFirstRate();
                    }
                    medZombie->resetHitRate();
                }
            }
        }

        for(auto& megaZombie : megaZombies){
            sf::Vector2f megaZombiePos = megaZombie->getPosition();

            if((megaZombiePos.y == iceshooterPos.y) && (megaZombiePos.x > iceshooterPos.x && megaZombiePos.x < (iceshooterPos.x + 40))){
                megaZombie->setPosition({megaZombiePos.x += dt*megaZombie->getSpeed(), megaZombiePos.y});
                if(gameTime >= megaZombie->getHitRate()){
                   if(megaZombie->isFirstRate()){
                        megaZombie->resetRateStatue();
                        megaZombie->setFirstHitRate(gameTime);
                    } else {
                        iceshooter->manageHealth(megaZombie->getDamage());
                        if(iceshooter->isDead())
                            megaZombie->setFirstRate();
                    }
                    megaZombie->resetHitRate();
                }
            }
        }
    }
}

void Game::checkZombiesEatingSunflower(float dt){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    for(auto& sunflower : sunflowers){
        sf::Vector2f sunflowerPos = sunflower->getPosition();
        
        for(auto& medZombie : mediumZombies){
            sf::Vector2f medZombiePos = medZombie->getPosition();

            if((medZombiePos.y == sunflowerPos.y) && (medZombiePos.x > sunflowerPos.x && medZombiePos.x < (sunflowerPos.x + 40))){
                medZombie->setPosition({medZombiePos.x += dt*medZombie->getSpeed(), medZombiePos.y});
                if(gameTime >= medZombie->getHitRate()){
                   if(medZombie->isFirstRate()) {
                        medZombie->resetRateStatue();
                        medZombie->setFirstHitRate(gameTime);
                    } else {
                        sunflower->manageHealth(medZombie->getDamage());
                        if(sunflower->isDead())
                            medZombie->setFirstRate();
                    }
                    medZombie->resetHitRate();
                }
            }
        }

        for(auto& megaZombie : megaZombies){
            sf::Vector2f megaZombiePos = megaZombie->getPosition();

            if((megaZombiePos.y == sunflowerPos.y) && (megaZombiePos.x > sunflowerPos.x && megaZombiePos.x < (sunflowerPos.x + 40))){
                megaZombie->setPosition({megaZombiePos.x += dt*megaZombie->getSpeed(), megaZombiePos.y});
                if(gameTime >= megaZombie->getHitRate()){
                   if(megaZombie->isFirstRate()){
                        megaZombie->resetRateStatue();
                        megaZombie->setFirstHitRate(gameTime);
                    } else {
                        sunflower->manageHealth(megaZombie->getDamage());
                        if(sunflower->isDead())
                            megaZombie->setFirstRate();
                    }
                    megaZombie->resetHitRate();
                }
            }
        }
    }
}

void Game::checkZombiesEatingWalnut(float dt){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    for(auto& walnut : walnuts){
        sf::Vector2f walnutPos = walnut->getPosition();
        
        for(auto& medZombie : mediumZombies){
            sf::Vector2f medZombiePos = medZombie->getPosition();

            if((medZombiePos.y == walnutPos.y) && (medZombiePos.x > walnutPos.x && medZombiePos.x < (walnutPos.x + 40))){
                medZombie->setPosition({medZombiePos.x += dt*medZombie->getSpeed(), medZombiePos.y});
                if(gameTime >= medZombie->getHitRate()){
                   if(medZombie->isFirstRate()) {
                        medZombie->resetRateStatue();
                        medZombie->setFirstHitRate(gameTime);
                    } else {
                        walnut->manageHealth(medZombie->getDamage());
                        if(walnut->isDead())
                            medZombie->setFirstRate();
                    }
                    medZombie->resetHitRate();
                }
            }
        }

        for(auto& megaZombie : megaZombies){
            sf::Vector2f megaZombiePos = megaZombie->getPosition();

            if((megaZombiePos.y == walnutPos.y) && (megaZombiePos.x > walnutPos.x && megaZombiePos.x < (walnutPos.x + 40))){
                megaZombie->setPosition({megaZombiePos.x += dt*megaZombie->getSpeed(), megaZombiePos.y});
                if(gameTime >= megaZombie->getHitRate()){
                   if(megaZombie->isFirstRate()){
                        megaZombie->resetRateStatue();
                        megaZombie->setFirstHitRate(gameTime);
                    } else {
                        walnut->manageHealth(megaZombie->getDamage());
                        if(walnut->isDead())
                            megaZombie->setFirstRate();
                    }
                    megaZombie->resetHitRate();
                }
            }
        }
    }
}