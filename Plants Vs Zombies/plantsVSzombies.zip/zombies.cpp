#include "zombies.hpp"
#include "plants.hpp"

MediumZombie::MediumZombie(const sf::Vector2f& pos) : position(pos) {
    damage = readFromFile("regular", DAMAGE);
    health = readFromFile("regular", HEALTH); 
    speed = readFromFile("regular", SPEED);
    hitRate = readFromFile("regular", HITRATE);

    texture.loadFromFile(MEDIUM_Zombie_TEXTURE_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.2f, 0.2f);
}

void MediumZombie::draw(sf::RenderWindow& window) {
    window.draw(sprite);
}

void MediumZombie::update(float dt, float gameTime){
    if(gameTime >= startingIceHitTime && iceHit){
        if(freezeTime <= 0){
            iceHit = false;
            speed = readFromFile("regular", SPEED);
        } else {
            speed = readFromFile("regular", SPEED)/2;
            freezeTime--;
            startingIceHitTime += ONE_SECOND;
        }
    }

    position.x -= speed*dt;
    sprite.setPosition(position);
}

void MediumZombie::manageHealth(int arrowDamage){
    health -= arrowDamage;
}

bool MediumZombie::isDead(){
    if(health <= 0)
        return true;
    return false;
}

void MediumZombie::handleIceHit(float hitTime) { 
    iceHit = true; 
    startingIceHitTime = hitTime; 
    freezeTime = ICE_FREEZE_TIME; 
}







MegaZombie::MegaZombie(const sf::Vector2f& pos) : position(pos) {
    damage = readFromFile("hairMetalGargantuar", DAMAGE);
    health = readFromFile("hairMetalGargantuar", HEALTH);
    speed = readFromFile("hairMetalGargantuar", SPEED);
    hitRate = readFromFile("hairMetalGargantuar", HITRATE);

    texture.loadFromFile(MEGA_Zombie_TEXTURE_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.18f, 0.18f);
}

void MegaZombie::draw(sf::RenderWindow& window) {
    window.draw(sprite);
}

void MegaZombie::update(float dt,float gameTime){
    if(gameTime >= startingIceHitTime && iceHit){
        if(freezeTime <= 0){
            iceHit = false;
            speed = readFromFile("hairMetalGargantuar", SPEED);
        }    
        else{
            speed = readFromFile("hairMetalGargantuar", SPEED) / 2;   
            freezeTime--;
            startingIceHitTime += ONE_SECOND; 
        }
    }
    position.x -= speed*dt;
    sprite.setPosition(position);
}

void MegaZombie::manageHealth(int arrowDamage){
    health -= arrowDamage;
}

bool MegaZombie::isDead(){
    if(health <= 0)
        return true;
    return false;
}
void MegaZombie::handleIceHit(float hitTime){
    iceHit = true; 
    startingIceHitTime = hitTime; 
    freezeTime = ICE_FREEZE_TIME; ;

} 