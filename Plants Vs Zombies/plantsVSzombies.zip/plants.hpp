#pragma once
#include <utility>
#include <string>
#include <iostream>
#include <vector>
#include "plants.hpp"
#include "blocks.hpp"
#include "header.hpp"
#include "zombies.hpp"
#include "start.hpp"
#include "game.hpp"
using namespace std;

bool hasCollision(const sf::Sprite& sprite1, const sf::Sprite& sprite2);
class Sunflower {
    public:
        Sunflower(const sf::Vector2f& position);
        void draw(sf::RenderWindow& window);
        void manageHealth(int damage);
        bool isDead();
        sf::Vector2f getPosition(){return position;}
        int getSpawnRate(){ return spawnRate; }
        void updateSpawnRate() { spawnRate += spawnRate; }
        void setSpawnRate(float start){ spawnRate = start; }

    private:
        sf::Vector2f position;
        sf::Texture texture;
        sf::Sprite sprite;
        int health;
        int spawnRate;
};
class PeaArrow {
    public:
        PeaArrow(const sf::Vector2f& pos);
        void draw(sf::RenderWindow& window);
        void update(float dt, vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies);
        bool isHit(){ return hadCollision; }

    private:
        sf::Vector2f position;
        sf::Texture texture;
        sf::Sprite sprite;
        int speed;
        int damage;
        bool hadCollision = false;
};
class Peashooter {
    public:
        Peashooter(const sf::Vector2f& position);
        void draw(sf::RenderWindow& window);
        void update(float dt, sf::Clock gameClock, vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies);
        void manageHealth(int damage);
        bool isDead(){ return Dead; }
        void spawnArrow();
        void removeArrow(PeaArrow* arrow);
        bool isZombieComing(vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies);
        sf::Vector2f getPosition() { return position; }

    private:
        sf::Vector2f position;
        sf::Texture texture;
        sf::Sprite sprite;
        vector<PeaArrow*> peaArrows;
        int health;
        int hitRate = 0; 
        bool Dead = false;
        bool firstSpawn = true;
};
class IceArrow {
    public:
        IceArrow(const sf::Vector2f& pos);
        void draw(sf::RenderWindow& window);
        void update(float dt, float gameTime, vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies);
        bool isHit(){return hadCollision;}
    private:
        sf::Vector2f position;
        sf::Texture texture;
        sf::Sprite sprite;
        int speed;
        int damage;
        bool hadCollision = false;
};
class IceShooter {
    public:
        IceShooter(const sf::Vector2f& position);
        void draw(sf::RenderWindow& window);
        void manageHealth(int damage);
        void update(float dt, sf::Clock gameClock, vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies);
        bool isDead(){return Dead;}
        void spawnArrow();
        void removeArrow(IceArrow* arrow);
        bool isZombiesComing(vector<MediumZombie*> mediumZombies, vector<MegaZombie*> megaZombies);
        sf::Vector2f getPosition(){return position;}

     
    private:
        sf::Vector2f position;
        sf::Texture texture;
        sf::Sprite sprite;
        vector<IceArrow*> iceArrows;
        int health;
        int hitRate = 0;
        bool Dead = false;
        bool firstSpawn = true;
};
class Walnut {
    public:
        Walnut(const sf::Vector2f& position);
        void draw(sf::RenderWindow& window);
        void manageHealth(int damage);
        bool isDead();
        sf::Vector2f getPosition(){return position;}
      
    private:
        sf::Vector2f position;
        sf::Texture bodyTexture;
        sf::Texture crackedTexture1;
        sf::Texture crackedTexture2;
        sf::Sprite sprite;
        int health;      
};