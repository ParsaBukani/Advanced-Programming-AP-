#pragma once

#include "blocks.hpp"
#include "header.hpp"
#include "zombies.hpp"
#include "readFile.hpp"

class Walnut;
class MegaZombie;
class MediumZombie;
class Sunflower;
class Peashooter;
class IceShooter;
class Bonus;
class StandingBonus;
class Game {
    private:
        sf::Clock gameClock;
        sf::Music music;

        int totallTimeToWin;
        int zombieSpawnRate;
        int numOfZombiesToSpawn;
        int numOfZombiesTOAdd;
        int SunSpawnRate;

        bool isLose = false;
        bool isWin = false;

        sf::Texture backgroundTexture;
        sf::Sprite backgroundSprite;
        
        vector<vector<pair<sf::Vector2f,bool>>> gridPositions;

        vector<Sunflower*> sunflowers;
        vector<Peashooter*> peashooters;
        vector<IceShooter*> iceShooters;
        vector<Walnut*> walnuts;
        vector<MediumZombie*> mediumZombies;
        vector<MegaZombie*> megaZombies;
        vector<Bonus*> bonuses;
        vector<StandingBonus*> standingbonuses;
        WalnutBlock walnutBlock;
        PeashooterBlock peashooterBlock;
        
        
        IceshooterBlock iceshooterBlock;
        SunflowerBlock sunflowerBlock;
        Sun sun;
    public:
        Game();
        void handleInput(sf::Event& event, sf::RenderWindow& window);
        void update(float dtSeconds, sf::RenderWindow& window);
        void render(sf::RenderWindow& window);
        int run(sf::RenderWindow& window);

        sf::Vector2f getGridCenterPosition(const sf::Vector2i& mousePosition);
        void fillGridCell(sf::Vector2f position);
        void resetGridCell(sf::Vector2f position);

        void addPeashooter(sf::Vector2f position);
        void addIceshooter(sf::Vector2f position);
        void addSunflower(sf::Vector2f position);
        void addWalnut(sf::Vector2f position);
        void addMediumZombie(sf::Vector2f position);
        void addMegaZombie(sf::Vector2f position);

        void spawnZombies();
        void removeMedZombie(MediumZombie* mediumZombie);
        void removeMegaZombie(MegaZombie* megaZombie);
        void removeIceshooter(IceShooter* iceshooter, sf::Vector2f position);
        void removePeashooter(Peashooter* peashooter, sf::Vector2f position);
        void removeSunflower(Sunflower* sunflower, sf::Vector2f position);
        void removeWulnut(Walnut* Walnut, sf::Vector2f position);

        void spawnSun();
        void spawnSun2(vector<Sunflower*> sunflowers);
        bool checkBonuses(const sf::Vector2i& mousePosition);
        void removeBonus(Bonus* bonus);

        void checkZombiesEatingPlants(float dt);
        void checkZombiesEatingPeashooter(float dt);
        void checkZombiesEatingIceshooter(float dt);
        void checkZombiesEatingWalnut(float dt);
        void checkZombiesEatingSunflower(float dt);

        bool checkStandingBonuses(const sf::Vector2i& mousePosition);
        void removeStandingBonus(StandingBonus* standingbonus);

        void checkPeashooterBlock(const sf::Vector2i& mousePosition, sf::RenderWindow& window);
        void checkWalnutBlock(const sf::Vector2i& mousePosition, sf::RenderWindow& window);
        void checkIceshooterBlock(const sf::Vector2i& mousePosition, sf::RenderWindow& window);
        void checkSunflowerBlock(const sf::Vector2i& mousePosition, sf::RenderWindow& window);

        void isLost(vector<MediumZombie*> mediumZombies,vector<MegaZombie*> megaZombies);
        void isWon(){if(gameClock.getElapsedTime().asSeconds() > totallTimeToWin) isWin = true;}

};