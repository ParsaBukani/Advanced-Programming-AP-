#include "blocks.hpp"
#include "readFile.hpp"



Sun::Sun(){
    position = {SUN_POSITION_X_AXIS, SUN_POSITION_Y_AXIS};
    texture.loadFromFile(SUN_TEXTUR_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.8f,0.8f);

    font.loadFromFile(TEXT_FILE_PATH);
    sunText.setFont(font);
    sunText.setCharacterSize(48);
    sunText.setFillColor(sf::Color::White);
    sunText.setPosition(SUN_POSITION_X_AXIS + 50, SUN_POSITION_Y_AXIS - 30);
    sunText.setString(": " + to_string(sunCount)); 
}

void Sun::draw(sf::RenderWindow& window) {
    window.draw(sprite);
    window.draw(sunText);
}

void Sun::update(){
    sunText.setString(": " + to_string(sunCount));
}



StandingBonus::StandingBonus(const sf::Vector2f& pos) : position(pos) {
    texture.loadFromFile(SUN_TEXTUR_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.5f,0.5f);
}

void StandingBonus::draw(sf::RenderWindow& window) {
    window.draw(sprite);
}




Bonus::Bonus(const sf::Vector2f& pos) : position(pos) {
    speed = readFromFile("sunflower", SPEED);

    texture.loadFromFile(SUN_TEXTUR_FILE_PATH);
    sprite.setTexture(texture);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.5f,0.5f);
}

void Bonus::draw(sf::RenderWindow& window) {
    window.draw(sprite);
}

void Bonus::update(float dt){
    position.y += dt*speed;
    sprite.setPosition(position);
}





PeashooterBlock::PeashooterBlock(){
    price = readFromFile("peashooter", PRICE);
    coolDown = readFromFile("peashooter", COOLDOWN);


    position = {BLOCK_TOP_CENTRE_X, BLOCK_TOP_CENTRE_Y + BLOCK_HEIGHT};
    activeTexture.loadFromFile(PEASHOOTER_ACTIVE_TEXTUR_FILE_PATH);
    inActiveTexture.loadFromFile(PEASHOOTER_INACTIVE_TEXTUR_FILE_PATH);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.4f,0.4f);

    font.loadFromFile(TEXT_FILE_PATH);
    sf::FloatRect textBounds = PeashooterBlockText.getLocalBounds();
    PeashooterBlockText.setOrigin(-45 + textBounds.width / 2, -5 + textBounds.height / 2);
    PeashooterBlockText.setFont(font);
    PeashooterBlockText.setCharacterSize(48);
    PeashooterBlockText.setFillColor(sf::Color::White);
    PeashooterBlockText.setPosition(BLOCK_TOP_CENTRE_X, BLOCK_TOP_CENTRE_Y +  BLOCK_HEIGHT);
    PeashooterBlockText.setString(to_string(inActivationCount));
    
    peashooterTex.loadFromFile("pics/Peashooter.png");
    peashooterSpr.setTexture(peashooterTex);
    sf::FloatRect pBounds = peashooterSpr.getLocalBounds();
    peashooterSpr.setOrigin(pBounds.width / 2, pBounds.height / 2);
    peashooterSpr.setScale(0.06f,0.06f);
}


void PeashooterBlock::draw(sf::RenderWindow& window) {
    if(statue == true){
        sprite.setTexture(activeTexture);
        window.draw(sprite);
    } else {
        sprite.setTexture(inActiveTexture);
        window.draw(sprite);

        if((inActivationCount != coolDown + 1) && (startCounting == true))
            window.draw(PeashooterBlockText);
    }

    if(isSpawning)
        window.draw(peashooterSpr);
}

void PeashooterBlock::spawn(sf::RenderWindow& window){
    statue = false;
    isSpawning = true;
    
    peashooterPos = sf::Vector2f(sf::Mouse::getPosition(window));
    peashooterSpr.setPosition(peashooterPos);
}

void PeashooterBlock::update(float dt, sf::Clock gameClock, sf::RenderWindow& window, int credit){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    if(isSpawning == true){
        peashooterPos = sf::Vector2f(sf::Mouse::getPosition(window));
        peashooterSpr.setPosition(peashooterPos);
    }

    if(statue == false && startCounting == true){
        if (gameTime >= inActivationTime) {
            statue = true;
            inActivationCount = coolDown + 1;
        } else {
            if(inActivationCount < 1){
                inActivationCount = coolDown + 1;
                startCounting = false;
                return;
            }
            inActivationCount = inActivationTime - gameTime;
            PeashooterBlockText.setString(to_string(inActivationCount));
        }
    }

    if(credit < price)
        statue = false;
    else if(isSpawning == false && startCounting == false)
        statue = true;
}

void PeashooterBlock::reset(sf::Clock gameClock, bool isInGridCell){ 
    isSpawning = false;
    if(isInGridCell){
        inActivationTime = gameClock.getElapsedTime().asSeconds() + coolDown + 1.5;
        startCounting = true;
    }
}





WalnutBlock::WalnutBlock(){
    price = readFromFile("walnut", PRICE);
    coolDown = readFromFile("walnut", COOLDOWN);

    position = {BLOCK_TOP_CENTRE_X, BLOCK_TOP_CENTRE_Y +  2* BLOCK_HEIGHT};
    activeTexture.loadFromFile(WALNUT_ACTIVE_TEXTUR_FILE_PATH);
    inActiveTexture.loadFromFile(WALNUT_INACTIVE_TEXTUR_FILE_PATH);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.4f,0.4f);

    font.loadFromFile(TEXT_FILE_PATH);
    sf::FloatRect textBounds = WalnutBlockText.getLocalBounds();
    WalnutBlockText.setOrigin(-45 + textBounds.width / 2, -5 + textBounds.height / 2);
    WalnutBlockText.setFont(font);
    WalnutBlockText.setCharacterSize(48);
    WalnutBlockText.setFillColor(sf::Color::White);
    WalnutBlockText.setPosition(BLOCK_TOP_CENTRE_X, BLOCK_TOP_CENTRE_Y + 2* BLOCK_HEIGHT);
    WalnutBlockText.setString(to_string(inActivationCount));
    
    walnutTex.loadFromFile("pics/Wallnut_body.png");
    walnutSpr.setTexture(walnutTex);
    sf::FloatRect pBounds = walnutSpr.getLocalBounds();
    walnutSpr.setOrigin(pBounds.width / 2, pBounds.height / 2);
    walnutSpr.setScale(0.75f,0.75f);
}

void WalnutBlock::draw(sf::RenderWindow& window) {
    if(statue == true){
        sprite.setTexture(activeTexture);
        window.draw(sprite);
    } else {
        sprite.setTexture(inActiveTexture);
        window.draw(sprite);

        if((inActivationCount != coolDown + 1) && (startCounting == true))
            window.draw(WalnutBlockText);
    }

    if(isSpawning)
        window.draw(walnutSpr);
}

void WalnutBlock::spawn(sf::RenderWindow& window){
    statue = false;
    isSpawning = true;
    
    walnutPos = sf::Vector2f(sf::Mouse::getPosition(window));
    walnutSpr.setPosition(walnutPos);
}

void WalnutBlock::update(float dt, sf::Clock gameClock, sf::RenderWindow& window, int credit){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    if(isSpawning == true){
        walnutPos = sf::Vector2f(sf::Mouse::getPosition(window));
        walnutSpr.setPosition(walnutPos);
    }

    if(statue == false && startCounting == true){
        if (gameTime >= inActivationTime) {
            statue = true;
            inActivationCount = coolDown + 1;
        } else {
            if(inActivationCount < 1){
                inActivationCount = coolDown + 1;
                startCounting = false;
                return;
            }
            inActivationCount = inActivationTime - gameTime;
            WalnutBlockText.setString(to_string(inActivationCount));
        }
    }

    if(credit < price)
        statue = false;
    else if(isSpawning == false && startCounting == false)
        statue = true;
}

void WalnutBlock::reset(sf::Clock gameClock, bool isInGridCell){ 
    isSpawning = false;
    if(isInGridCell){
        inActivationTime = gameClock.getElapsedTime().asSeconds() + coolDown + 1.5;
        startCounting = true;
    }
}





IceshooterBlock::IceshooterBlock(){
    price = readFromFile("iceshooter", PRICE);
    coolDown = readFromFile("iceshooter", COOLDOWN);

    position = {BLOCK_TOP_CENTRE_X, BLOCK_TOP_CENTRE_Y + 3* BLOCK_HEIGHT};
    activeTexture.loadFromFile(ICESHOOTER_ACTIVE_TEXTUR_FILE_PATH);
    inActiveTexture.loadFromFile(ICESHOOTER_INACTIVE_TEXTUR_FILE_PATH);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.4f,0.4f);

    font.loadFromFile(TEXT_FILE_PATH);
    sf::FloatRect textBounds = IceshooterBlockText.getLocalBounds();
    IceshooterBlockText.setOrigin(-45 + textBounds.width / 2, -5 + textBounds.height / 2);
    IceshooterBlockText.setFont(font);
    IceshooterBlockText.setCharacterSize(48);
    IceshooterBlockText.setFillColor(sf::Color::White);
    IceshooterBlockText.setPosition(BLOCK_TOP_CENTRE_X, BLOCK_TOP_CENTRE_Y + 3* BLOCK_HEIGHT);
    IceshooterBlockText.setString(to_string(inActivationCount));
    
    iceshooterTex.loadFromFile("pics/iceshooter-icon.png");
    iceshooterSpr.setTexture(iceshooterTex);
    sf::FloatRect pBounds = iceshooterSpr.getLocalBounds();
    iceshooterSpr.setOrigin(pBounds.width / 2, pBounds.height / 2);
    iceshooterSpr.setScale(0.08f,0.06f);
}

void IceshooterBlock::draw(sf::RenderWindow& window) {
    if(statue == true){
        sprite.setTexture(activeTexture);
        window.draw(sprite);
    } else {
        sprite.setTexture(inActiveTexture);
        window.draw(sprite);

        if((inActivationCount != coolDown + 1) && (startCounting == true))
            window.draw(IceshooterBlockText);
    }

    if(isSpawning)
        window.draw(iceshooterSpr);
}

void IceshooterBlock::spawn(sf::RenderWindow& window){
    statue = false;
    isSpawning = true;
    
    iceshooterPos = sf::Vector2f(sf::Mouse::getPosition(window));
    iceshooterSpr.setPosition(iceshooterPos);
}

void IceshooterBlock::update(float dt, sf::Clock gameClock, sf::RenderWindow& window, int credit){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    if(isSpawning == true){
        iceshooterPos = sf::Vector2f(sf::Mouse::getPosition(window));
        iceshooterSpr.setPosition(iceshooterPos);
    }

    if(statue == false && startCounting == true){
        if (gameTime >= inActivationTime) {
            statue = true;
            inActivationCount = coolDown + 1;
        } else {
            if(inActivationCount < 1){
                inActivationCount = coolDown + 1;
                startCounting = false;
                return;
            }
            inActivationCount = inActivationTime - gameTime;
            IceshooterBlockText.setString(to_string(inActivationCount));
        }
    }

    if(credit < price)
        statue = false;
    else if(isSpawning == false && startCounting == false)
        statue = true;
}

void IceshooterBlock::reset(sf::Clock gameClock, bool isInGridCell){ 
    isSpawning = false;
    if(isInGridCell){
        inActivationTime = gameClock.getElapsedTime().asSeconds() + coolDown + 1.5;
        startCounting = true;
    }
}




SunflowerBlock::SunflowerBlock(){
    price = readFromFile("sunflower", PRICE);
    coolDown = readFromFile("sunflower", COOLDOWN);

    position = {BLOCK_TOP_CENTRE_X, BLOCK_TOP_CENTRE_Y + 4* BLOCK_HEIGHT};
    activeTexture.loadFromFile(SUNFLOWER_ACTIVE_TEXTUR_FILE_PATH);
    inActiveTexture.loadFromFile(SUNFLOWER_INACTIVE_TEXTUR_FILE_PATH);
    sf::FloatRect bounds = sprite.getGlobalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setPosition(position);
    sprite.setScale(0.4f,0.4f);

    font.loadFromFile(TEXT_FILE_PATH);
    sf::FloatRect textBounds = SunflowerBlockText.getLocalBounds();
    SunflowerBlockText.setOrigin(-45 + textBounds.width / 2, -5 + textBounds.height / 2);
    SunflowerBlockText.setFont(font);
    SunflowerBlockText.setCharacterSize(48);
    SunflowerBlockText.setFillColor(sf::Color::White);
    SunflowerBlockText.setPosition(BLOCK_TOP_CENTRE_X, BLOCK_TOP_CENTRE_Y + 4* BLOCK_HEIGHT);
    SunflowerBlockText.setString(to_string(inActivationCount));
    
    sunflowerTex.loadFromFile("pics/Sunflower.png");
    sunflowerSpr.setTexture(sunflowerTex);
    sf::FloatRect pBounds = sunflowerSpr.getLocalBounds();
    sunflowerSpr.setOrigin(pBounds.width / 2, pBounds.height / 2);
    sunflowerSpr.setScale(0.06f,0.06f);
}

void SunflowerBlock::draw(sf::RenderWindow& window) {
    if(statue == true){
        sprite.setTexture(activeTexture);
        window.draw(sprite);
    } else {
        sprite.setTexture(inActiveTexture);
        window.draw(sprite);

        if((inActivationCount != coolDown + 1) && (startCounting == true))
            window.draw(SunflowerBlockText);
    }

    if(isSpawning)
        window.draw(sunflowerSpr);
}

void SunflowerBlock::spawn(sf::RenderWindow& window){
    statue = false;
    isSpawning = true;
    
    sunflowerPos = sf::Vector2f(sf::Mouse::getPosition(window));
    sunflowerSpr.setPosition(sunflowerPos);
}

void SunflowerBlock::update(float dt, sf::Clock gameClock, sf::RenderWindow& window, int credit){
    float gameTime = gameClock.getElapsedTime().asSeconds();

    if(isSpawning == true){
        sunflowerPos = sf::Vector2f(sf::Mouse::getPosition(window));
        sunflowerSpr.setPosition(sunflowerPos);
    }

    if(statue == false && startCounting == true){
        if (gameTime >= inActivationTime) {
            statue = true;
            inActivationCount = coolDown + 1;
        } else {
            if(inActivationCount < 1){
                inActivationCount = coolDown + 1;
                startCounting = false;
                return;
            }
            inActivationCount = inActivationTime - gameTime;
            SunflowerBlockText.setString(to_string(inActivationCount));
        }
    }

    if(credit < price)
        statue = false;
    else if(isSpawning == false && startCounting == false)
        statue = true;
}

void SunflowerBlock::reset(sf::Clock gameClock, bool isInGridCell){ 
    isSpawning = false;
    if(isInGridCell){
        inActivationTime = gameClock.getElapsedTime().asSeconds() + coolDown + 1.5;
        startCounting = true;
    }
}