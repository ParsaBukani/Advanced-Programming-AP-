#include "header.hpp"
#include "start.hpp"


bool isGameStarted(){
    sf::RenderWindow w2(sf::VideoMode(1100,650),"start");
    sf::Texture t;
    t.loadFromFile("pics/Starting_Screen.png");
    sf::Sprite s(t);
    w2.draw(s);
    w2.display();

    while (w2.isOpen())
    {
        sf::Event e;
        while (w2.pollEvent(e))
        {
            if (e.type == sf::Event::Closed){
                w2.close();
                return false;
            }
            if (e.type == sf::Event::KeyPressed)
            {
                if (e.key.code == sf::Keyboard::Space)
                   w2.close();
            }
        }
    }
    return true;
}

bool gameIsFinishedWasted(){
    sf::RenderWindow w2(sf::VideoMode(1100,600),"start");
    sf::Texture t;
    t.loadFromFile("pics/Losing_Message.png");
    sf::Sprite s(t);
    s.setScale(2.29f,1.875f);
    w2.draw(s);
    w2.display();

    while (w2.isOpen())
    {
        sf::Event e;
        while (w2.pollEvent(e))
        {
            if (e.type == sf::Event::Closed){
                w2.close();
                return false;
            }
            if (e.type == sf::Event::KeyPressed)
            {
                if (e.key.code == sf::Keyboard::Space)
                   w2.close();
            }
        }
    }
    return true;
}
bool gameIsFinishedWon(){
    sf::RenderWindow w2(sf::VideoMode(1100,600),"start");
    sf::Texture t;
    t.loadFromFile("pics/Winning_Pic.png");
    sf::Sprite s(t);
    w2.draw(s);
    w2.display();

    while (w2.isOpen())
    {
        sf::Event e;
        while (w2.pollEvent(e))
        {
            if (e.type == sf::Event::Closed){
                w2.close();
                return false;
            }
            if (e.type == sf::Event::KeyPressed)
            {
                if (e.key.code == sf::Keyboard::Space)
                   w2.close();
            }
        }
    }
    return true;
}