#pragma once
#include "header.hpp"
bool isGameStarted();
bool gameIsFinishedWasted();
bool gameIsFinishedWon();