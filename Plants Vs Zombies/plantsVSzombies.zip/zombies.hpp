#pragma once
#include "plants.hpp"
#include "blocks.hpp"
#include "header.hpp"
#include "start.hpp"
#include "game.hpp"
#include <utility>
#include <string>
#include <iostream>
#include <vector>

class MediumZombie {
public:
    MediumZombie(const sf::Vector2f& position);

    void update(float dtSeconds, float gameTime);
    void draw(sf::RenderWindow& window);
    void manageHealth(int arrowDamage);
    bool isDead();
    int getDamage(){ return damage; }
    int gethitRate(){ return hitRate; }
    sf::Sprite getSprite(){ return sprite; }

    sf::Vector2f getPosition(){ return position; }
    void setPosition(sf::Vector2f pos) { position = pos; }
    int getSpeed(){ return speed; }

    bool isFirstRate() { return firstRate; }
    void setFirstRate() { firstRate = true; }
    void resetRateStatue() { firstRate = false; }

    int getHitRate() { return hitRate; }
    void setFirstHitRate(float first){ hitRate = first; }
    void resetHitRate() { hitRate += 3; }

    bool isIceHit(){ return iceHit; }
    void handleIceHit(float hitTime);

private:
    sf::Vector2f position;
    sf::Texture texture;
    sf::Sprite sprite;
    int health;
    int damage;
    int speed;
    int hitRate;
    bool firstRate = true;
    bool iceHit = false;
    float startingIceHitTime;
    int freezeTime;

};
class MegaZombie {
public:
    MegaZombie(const sf::Vector2f& position);

    void update(float ,float gameTime);
    void draw(sf::RenderWindow& window);
    void manageHealth(int arrowDamage);
    bool isDead();
    int getDamage(){ return damage; }
    int gethitRate(){ return hitRate; }
    sf::Sprite getSprite(){ return sprite; }
    sf::Vector2f getPosition(){ return position; }
    void setPosition(sf::Vector2f pos) { position = pos; }
    int getSpeed(){ return speed; }

    bool isFirstRate() { return firstRate; }
    void setFirstRate() { firstRate = true; }
    void resetRateStatue() { firstRate = false; }

    int getHitRate() { return hitRate; }
    void setFirstHitRate(float first){ hitRate = first; }
    void resetHitRate() { hitRate += 3; }
    void handleIceHit(float hitTime);

private:
    sf::Vector2f position;
    sf::Texture texture;
    sf::Sprite sprite;
    int health;
    int damage;
    int speed;
    int hitRate;
    bool firstRate = true;
    bool iceHit = false;
    float startingIceHitTime;
    int freezeTime;

};